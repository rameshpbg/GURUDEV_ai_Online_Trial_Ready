import json
import pandas as pd
import pytest
from gurudev_ai.demo import generate
from gurudev_ai.data import load_dataset
from gurudev_ai.gp import train_nested
from gurudev_ai.jobs import execute, recent_jobs
from gurudev_ai.planner import deterministic_plan


def test_dataset_alignment_and_encoded_values(tmp_path):
    g, p = generate(tmp_path)
    ds = load_dataset(g, p, "grain_yield")
    assert ds.X.shape == (72, 32)
    assert list(ds.X.index) == ds.ids
    assert ds.qc["matched_samples"] == 72
    assert set(ds.X.stack().unique()).issubset({0., 1., 2.})


def test_nested_gp_oof_and_cv(tmp_path):
    g, p = generate(tmp_path)
    ds = load_dataset(g, p, "grain_yield")
    fitted = train_nested(ds)
    assert fitted.predictions.shape[0] == 72
    assert fitted.predictions["predicted_oof"].notna().all()
    assert len(fitted.fold_details) == 4
    assert fitted.metrics["RMSE"] >= 0


def test_grouped_no_family_leakage(tmp_path):
    g, p = generate(tmp_path)
    ds = load_dataset(g, p, "grain_yield", group_column="family")
    fitted = train_nested(ds)
    assert len(fitted.fold_details) == 4
    assert fitted.parameters["validation"] == "nested_group_cv"


def test_duplicate_ids_rejected(tmp_path):
    g, p = generate(tmp_path)
    df = pd.read_csv(g)
    df.loc[1, "sample_id"] = df.loc[0, "sample_id"]
    df.to_csv(g, index=False)
    with pytest.raises(ValueError, match="duplicated"):
        load_dataset(g, p, "grain_yield")


def test_no_overlap_fails(tmp_path):
    g, p = generate(tmp_path)
    df = pd.read_csv(p)
    df["sample_id"] = "X" + df["sample_id"]
    df.to_csv(p, index=False)
    with pytest.raises(ValueError, match="No matching"):
        load_dataset(g, p, "grain_yield")


def test_job_records_outputs(tmp_path):
    g, p = generate(tmp_path / "input")
    folder, meta = execute("qc", g, p, "grain_yield", tmp_path / "runs")
    assert meta["status"] == "completed"
    assert json.loads((folder / "manifest.json").read_text())["files"]["genotype"]["sha256"]
    assert (folder / "events.jsonl").exists()
    assert recent_jobs(tmp_path / "runs")[0][2] == "completed"


def test_allowlisted_planner():
    assert deterministic_plan("Conduct genomic prediction for yield")["route"] == "gp"
    assert deterministic_plan("Design CRISPR experiment")["route"] == "unsupported"
