import pandas as pd
import numpy as np
import pytest
from gurudev_ai.breeder_engine.workflow import run_campaign,get_campaign
from gurudev_ai.breeder_engine.external import evaluate_external
from test_breeder_engine import breeding_fixture


def test_frozen_model_external_validation_without_refit(tmp_path):
    g,p=breeding_fixture(signal=True)
    m=run_campaign(g,p,'yield',tmp_path)
    original=(tmp_path/m['job_id']/'trained_gblup_model.npz').read_bytes()
    gd=pd.read_csv(__import__('io').BytesIO(g)).iloc[:24].copy()
    gd['sample_id']=['UNSEEN_'+str(i) for i in range(len(gd))]
    rng=np.random.default_rng(44)
    y=7+gd.filter(regex='^SNP_').to_numpy()[:,:12].sum(axis=1)+rng.normal(size=len(gd))
    pdh=pd.DataFrame({'sample_id':gd.sample_id,'yield':y})
    ev=evaluate_external(tmp_path,m['job_id'],gd.to_csv(index=False).encode(),pdh.to_csv(index=False).encode(),'yield')
    assert ev['n_samples']==24
    assert (tmp_path/m['job_id']/'trained_gblup_model.npz').read_bytes()==original
    assert get_campaign(tmp_path,m['job_id'])['audit_chain_valid']
    with pytest.raises(ValueError,match='already been evaluated'):
        evaluate_external(tmp_path,m['job_id'],gd.to_csv(index=False).encode(),pdh.to_csv(index=False).encode(),'yield')


def test_external_leakage_guard_rejects_existing_ids(tmp_path):
    g,p=breeding_fixture(signal=True)
    m=run_campaign(g,p,'yield',tmp_path)
    with pytest.raises(ValueError,match='training sample'):
        evaluate_external(tmp_path,m['job_id'],g,p,'yield')
