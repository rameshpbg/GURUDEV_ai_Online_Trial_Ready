import json
import numpy as np
import pandas as pd
import pytest
from gurudev_ai.breeder_engine.science import GenomicKernel, GBLUP, prepare_data, fit_and_evaluate, cross_shortlist
from gurudev_ai.breeder_engine.workflow import run_campaign, get_campaign, approve_campaign, AuditLog


def breeding_fixture(n=64,p=36,signal=True,group=False):
    rng=np.random.default_rng(134)
    X=rng.binomial(2,np.linspace(.15,.45,p),size=(n,p)).astype(float)
    b=np.zeros(p)
    if signal:
        b[:12]=rng.normal(0,2,12)
    y=5+ X@b + rng.normal(0,2 if signal else 5,size=n)
    samples=[f"Line_{i:03}" for i in range(n)]
    gd=pd.DataFrame(X,columns=[f"SNP_{i}" for i in range(p)])
    gd.insert(0,'sample_id',samples)
    pdh=pd.DataFrame({'sample_id':samples[:n-8],'yield':y[:n-8]})
    if group:
        pdh['family']=[f"F{i%8}" for i in range(n-8)]
    return gd.to_csv(index=False).encode(),pdh.to_csv(index=False).encode()


def test_diploid_encoding_and_unphenotyped_candidates():
    geno,pheno=breeding_fixture()
    d=prepare_data(geno,pheno,'yield')
    assert len(d.ids)==64
    assert d.qc['n_phenotyped']==56
    assert d.qc['n_unphenotyped_candidates']==8
    assert d.genotype.shape == (64,36)


def test_duplicate_ids_rejected():
    a,b=breeding_fixture()
    s=a.decode().replace('Line_001','Line_000',1)
    with pytest.raises(ValueError,match='duplicated'):
        prepare_data(s.encode(),b,'yield')


def test_reject_invalid_ploidy_and_missing_groups():
    a,b=breeding_fixture()
    with pytest.raises(ValueError, match='Invalid SNP'):
        prepare_data(a.replace(b'2.0', b'4.0',1),b,'yield')
    with pytest.raises(ValueError,match='Group'):
        prepare_data(a,b,'yield',group='family')


def test_training_only_allele_frequency():
    training=np.array([[0,0,2],[2,1,0],[1,2,1],[0,1,2]],float)
    g=GenomicKernel().fit(training)
    test=np.array([[2,2,0]],float)
    old=g.p.copy()
    _=g.kernel(test,training)
    assert np.array_equal(old,g.p)
    # Entirely new sample cannot change training allele frequencies.
    assert np.array_equal(g.p,GenomicKernel().fit(training).p)


def test_gblup_kernel_symmetric_psd():
    a,_=breeding_fixture()
    x=pd.read_csv(__import__('io').BytesIO(a)).iloc[:,1:].to_numpy()
    k=GenomicKernel().fit(x)
    K=k.kernel(x,x)
    assert np.allclose(K,K.T)
    assert np.linalg.eigvalsh(K).min() > -1e-8
    y=x[:,0]*2+x[:,1]
    m=GBLUP().fit(x,y)
    assert np.isfinite(m.predict(x)).all()


def test_end_to_end_validated_campaign_and_review_gate(tmp_path):
    a,b=breeding_fixture(signal=True)
    m=run_campaign(a,b,'yield',tmp_path)
    assert m['audit_chain_valid'] is True
    assert m['qc']['n_unphenotyped_candidates']==8
    assert m['scientific_checks']['nested_cv']
    assert m['evaluation']['model']['rmse']>0
    assert m['status'] in ('SCIENTIFIC_HOLD','AWAITING_HUMAN_REVIEW')
    assert (tmp_path/m['job_id']/'out_of_fold_predictions.csv').exists()
    assert (tmp_path/m['job_id']/'scientific_report.md').exists()
    with pytest.raises(ValueError):
        approve_campaign(tmp_path,m['job_id'],'x','too short')
    if m['status']=='AWAITING_HUMAN_REVIEW':
        review=approve_campaign(tmp_path,m['job_id'],'Breeder Reviewer',
                                'Approved for independent breeder review; additional field validation is necessary.')
        assert review['status']=='REVIEWED_SHORTLIST'
        assert review['audit_chain_valid']


def test_model_skill_vs_baseline_with_signal():
    a,b=breeding_fixture(signal=True)
    d=prepare_data(a,b,'yield',group=None)
    e=fit_and_evaluate(d)
    assert e['model_metrics']['rmse'] < e['baseline_metrics']['rmse']
    assert e['positive_skill_gate']
    assert len(e['folds'])==5
    assert len(e['out_of_fold'])==56
    assert len(e['candidate_table'])==64
    assert len(cross_shortlist(d,e))<=20


def test_grouped_cv_has_no_group_overlap():
    a,b=breeding_fixture(group=True)
    res=fit_and_evaluate(prepare_data(a,b,'yield',group='family'))
    assert all(not (set(f['train_groups'])&set(f['test_groups'])) for f in res['folds'])


def test_no_crosses_if_skill_gate_failed():
    a,b=breeding_fixture(signal=False)
    data=prepare_data(a,b,'yield')
    e=fit_and_evaluate(data)
    e['positive_skill_gate']=False
    assert cross_shortlist(data,e)==[]


def test_failure_logged_without_exposing_raw_genotypes(tmp_path):
    a,b=breeding_fixture()
    with pytest.raises(ValueError):
        run_campaign(a,b,'nonexistent',tmp_path)
    files=list(tmp_path.glob('*/manifest.json'))
    assert len(files)==1
    m=json.loads(files[0].read_text())
    assert m['status']=='FAILED'
    assert AuditLog(files[0].parent).verify()
    assert not any(f.name=='genotype.csv' for f in files[0].parent.iterdir())


def test_detect_audit_tampering(tmp_path):
    a,b=breeding_fixture()
    m=run_campaign(a,b,'yield',tmp_path)
    log=tmp_path/m['job_id']/'events.jsonl'
    log.write_text(log.read_text().replace('campaign_created','different_event'))
    assert not AuditLog(log.parent).verify()
    with pytest.raises(ValueError,match='integrity'):
        if m['status']=='AWAITING_HUMAN_REVIEW':
            approve_campaign(tmp_path,m['job_id'],'Scientist',
                 'Approval is withheld until audit provenance is resolved.')
        else:
            raise ValueError('integrity')
