from io import BytesIO
from pathlib import Path
import os
from fastapi.testclient import TestClient
from gurudev_ai.companion.server import create_app
from test_breeder_engine import breeding_fixture


def test_campaign_api_and_literature_faithfulness(tmp_path,monkeypatch):
    monkeypatch.setenv('GURUDEV_CAMPAIGNS',str(tmp_path))
    client=TestClient(create_app())
    a,b=breeding_fixture()
    resp=client.post('/api/breeding/campaign',data={'trait':'yield','direction':'max'},
      files={'genotype':('g.csv',a,'text/csv'),'phenotype':('p.csv',b,'text/csv')})
    assert resp.status_code==200,resp.text
    record=resp.json()
    assert record['scientific_checks']['prospective_external_validation'] is False
    assert client.get(f"/api/breeding/campaign/{record['job_id']}").json()['audit_chain_valid']
    assert client.get(f"/api/breeding/campaign/{record['job_id']}/report").status_code==200
    assert client.get(f"/api/breeding/campaign/{record['job_id']}/report").text.count('NOT external')>=1
    html=client.get('/').text
    assert 'Breeding campaign' in html or 'breeding campaign' in html
    assert 'external-form' in html


def test_campaign_api_rejects_inappropriate_data(tmp_path,monkeypatch):
    monkeypatch.setenv('GURUDEV_CAMPAIGNS',str(tmp_path))
    client=TestClient(create_app())
    a,b=breeding_fixture()
    bad=client.post('/api/breeding/campaign',data={'trait':'unknown'},
        files={'genotype':('g.csv',a,'text/csv'),'phenotype':('p.csv',b,'text/csv')})
    assert bad.status_code==422
    assert client.get('/api/breeding/campaign/'+('b'*32)).status_code==404
