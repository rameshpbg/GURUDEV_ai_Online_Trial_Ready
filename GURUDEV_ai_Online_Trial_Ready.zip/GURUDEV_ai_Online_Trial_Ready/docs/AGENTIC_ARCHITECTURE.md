# GURUDEV.ai — Roadmap to a Research-Grade Agentic Breeding Platform

## Product north star

One conversational workspace spanning breeding experiments, design-aware statistical inference, germplasm data, field books, GWAS/QTL, genomic prediction, crossing, MAGIC, molecular breeding, phenomics and bioinformatics. Crop-agnostic and ploidy-aware. Human scientist remains accountable for model choices, empirical conclusions, field action and external release.

## 0.2 implementation boundaries (tested)

```
Researcher → Web Voice / Text / Forms → FastAPI companion API
                                        ├─ Read-only offline conversational router
                                        ├─ Optional cloud LLM (no uncontrolled tool use)
                                        ├─ SQLite: field book, task register, chat
                                        ├─ Trait trial CSV structural QC
                                        ├─ Exploratory parent ranking
                                        └─ GP Auto-Lab → QC → nested CV → audit → verify report
```

The package remains offline-first for data analysis, but browser speech recognition may rely on a vendor service. There are no background autonomous workers. The UI must clearly distinguish evidence, interpretation and hypotheses.

## Agentic evolution, approval and modularity

### Milestone A: Stable scientific tool contract
Every GURUDEV module exposes `describe_inputs`, `validate`, `run`, `verify`, `report`; includes domain assumptions, supported ploidy, resource estimates, seed, environment and test snapshots. Do not integrate legacy R packages before source-code inspection and comparative regression testing.

### Milestone B: Bounded agent loop
Implement deliberate planner → allowlisted tool router → parameter validator → containerized runner → scientific verification → bounded remediator → retest → final deliverables. Persist state to resume after interruption and require clear approval checkpoints. No arbitrary shell commands or code patches directly from the chat model.

### Milestone C: Scientific breeding agents
Experimental Design; Trait Architecture; GWAS/QTL; GP & Multi-Trait; Breeding Simulation & Crossing; Image/Digital Phenotyping; Genomics/Omics; Seed/Field Operations; Biotechnology Research; Scientific Writer & Reviewer. Use datasets only with consent and access controls.

### Milestone D: Breeder companion field mode
Responsive PWA and mobile support; optional approved offline/on-device STT/TTS; plot-level record identifiers, photos with provenance, environment-specific advice grounded in local data, farmer/breeder role access and synchronization after consent.

### Milestone E: Institutional deployment
Authentications, project ACLs, private model gateway, encryption, document provenance, job isolation, queues, real-data and multi-environment scientific benchmarks, restore tests, cost ceilings, security review and continuity monitoring.

## Training, learning and auto-debug definition

- **ML model fitting and tuning:** automatically run inside robust, leakage-controlled splits with a locked external test set where appropriate.
- **Knowledge updates:** accept new validated reference material and dated scientific decisions into a versioned corpus; retrieval with provenance and revision control.
- **LLM training/fine-tuning:** a separate evaluated process, never an assumption that the model learns permanently from conversations.
- **Auto-debug:** classify errors, apply only audited allowlisted non-scientific repairs, rerun tests and retain logs; never silently alter scientific models or phenotypes.

## Hand-off checklist
1. Ingest authoritative sources from Diversity, E-Design, GWAS.
2. Capture expected scientific outputs and tests.
3. Build adapters without modifying validated originals.
4. Add integrated module contracts.
5. Benchmark on representative real rice research datasets.
6. Expand to crops with different ploidy/inheritance after model validation.
