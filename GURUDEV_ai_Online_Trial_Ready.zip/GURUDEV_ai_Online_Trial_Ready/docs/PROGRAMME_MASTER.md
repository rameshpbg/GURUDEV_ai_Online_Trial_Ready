# GURUDEV.ai — programme master (2026-10-09)

**Mission:** modular, crop-independent, agentic AI infrastructure for credible analysis, experiments and decision support in plant breeding and biotechnology; rice as initial reference crop.

## Domain workstreams
- Genetics and plant breeding: diversity, association analysis (GWAS), linkage QTL, haplotypes, marker validation, selection indices, genomic prediction, G×E, multi-environment breeding and parent/cross optimization.
- Experimental design: CRD, RCBD, alpha-lattice, split/split-split plot, repeated measures, mixed models and diagnostics.
- Biotechnology: transcriptomics, multi-omics, biomarker discovery, breeding informatics, functional genomics, genetics and biotech research documentation.
- Digital phenomics and precision agriculture: image analysis, high-throughput phenotyping, digital twins and trait prediction.
- Translation: reproducible protocols, scientific reports, germplasm decisions, publication-ready outputs and documented IP exploration (subject to expert review).

## Principles
- User selects programme intent; agents prepare plans, execute allowlisted code, verify evidence and produce detailed reports.
- Never silently modify or overwrite raw datasets or validated package versions.
- All research claims require traceable data, methods, assumptions, metrics and validation.
- Advanced autonomy is bounded by scientific safety, permissions, compute budgets, resource limits, audit trails and human approval of major decisions.
- Data and source files are canonical. Chat memory, summaries and the AI context window are not authoritative source control.

## Initial modules (reported legacy state, not independently verified)
- GURUDEV Diversity: historical v6.8.9 baseline to retrieve and inspect.
- GURUDEV E-Design: historical v1.0.0 standalone package to inspect.
- GURUDEV GWAS: historical prototype; validate GAPIT, FarmCPU/BLINK, mrMLM and statistical model outputs independently.
- GURUDEV GP and parental simulation: planned; this starter delivers ONLY numeric biallelic GP baseline with nested CV.

## Initial release v0.1 (implemented locally)
- Allowlisted research routing (opt-in advisory LLM planner).
- CSV genotype/phenotype QC and ID alignment.
- Nested Ridge/ElasticNet predictor evaluation, grouped or random CV, local job tracker, per-job audit and reports.
- Optional Streamlit UI with clear implemented/planned module status.

## Next milestones (proposed; no unverified calendar deadlines)
1. M1 scientific acceptance tests, benchmark datasets, software-source retrieval and repository creation.
2. M2 authenticated frontend, module API, job queue, container isolation, versioned datasets/artifacts.
3. M3 vetted R adapters for Diversity, E-Design and GWAS; full golden/regression comparisons.
4. M4 GP statistical expansion and multi-environment/relatedness-aware model validation.
5. M5 breeding simulation, haplotype founders, genomic mating/selection optimization.
6. M6 digital phenomics, multi-omics and biotechnology modules, each separately reviewed.
7. M7 production hardening, audit governance, pilot with real rice datasets, publication-ready software.

## Release approval
Module owner signs off: methodological verification, representative benchmark, independent test, regression suite, error logs and documentation. GURUDEV.ai must never claim scientific validity based only on code running.
