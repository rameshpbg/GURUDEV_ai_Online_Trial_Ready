# GURUDEV.ai — Scientific acceptance gates

**Product goal:** high-reliability, multi-crop agentic breeding research system. This document describes release criteria, NOT completed claims.

## Phase 0 / Completed technical evidence (v0.3)

- [x] Local backend and responsive voice-ready companion retained from v0.2; source navigation updated.
- [x] End-to-end genotype QC / nested kernel GBLUP / predictive-skill gate / conditional shortlist / report.
- [x] Cross-validation uses train-fold-only SNP filters, imputation and allele frequencies.
- [x] Independent frozen model evaluation implemented and tested with distinct synthetic sample IDs.
- [x] Human review status, traceable hash-chain events, no-pickle model artifact, API routes and CLI.
- [x] High-resolution, correctly labelled internal-evidence figures.
- [ ] Actual field/microphone Android/iOS/desktop multilingual acceptance test.
- [ ] Independent agronomic data benchmark (no genuine field datasets were provided).
- [ ] Model-to-model numerical agreement with rrBLUP / BGLR reference implementations.
- [ ] Secure public deployment, live long-running agent loop.

## Phase 1 / External scientific reference suite (required before research production)

1. Independent plant breeding panel representing distinct families, environments and seasons, with data dictionary; if sample-level repeat measurements, infer corrected means through design-aware analysis before GP.
2. Verify biological sample and SNP ID alignment, allele reference orientation, missingness distributions, technical batches, ploidy and QC.
3. Explicit validation task (CV1, CV2, leave-family-out, leave-location-out, forward year prediction), selected **before** model tuning. Nested CV within training data; final prospective holdout untouched.
4. Benchmark GBLUP estimates and prediction against independently validated R reference software at reasonable tolerances, and compare to naive baseline and genetic-relatedness-only baselines.
5. Model reliability, calibration, uncertainty under breeding selection, bias, expected genetic gain and out-of-distribution drift; document failure modes.
6. External blinded benchmark should be reproducible on a second machine with pinned software and pre-registered acceptance criteria.
7. No release of automated crossing/selection recommendations without biological constraints and human sign-off. Exploratory midparent proxies are not genomic mating optimization.

## Phase 2 / Scientific modules (independently validated)

- Experimental design: CRD, RCBD, alpha-lattice, augmented designs, mixed models, BLUE/BLUP, residual diagnostics and spatial analysis with replication checks.
- Genetic diversity: population structure and F-statistics, LD decay, kinship and core set selection.
- GWAS/QTL: GLM, MLM, FarmCPU, BLINK, mrMLM, multi-locus mapping, controlled significance/FDR, independent reanalysis and gene-ID mapping.
- Prediction: GBLUP, Bayesian alphabet, ENET, RF, XGB, multi-trait, G×E, transfer across environments, missing phenotype imputation with leakage prevention.
- Genetic improvement: parent crossing optimization, within-family progeny simulation, constraints on inbreeding, genomic diversity and long-term gain.
- Phenomics/biotechnology: image, lab and multiomics analysis, all with assay-aware controls, batch effects, quality assurance and reproducible conclusions.

## Phase 3 / Agentic operation and governance

- User intent -> proposed scientific plan -> allowlisted tools -> data checks -> calibrated diagnostics -> bounded correction/retry -> independent review -> report. Real agent is *not allowed* to invent biological parameters or adjust statistical thresholds to manufacture success.
- Persistent queue with durable checkpoints, restart/retry and user cancellation. Resource quotas and cryptographically anchored artifact records.
- Controlled code-update cycle: propose patch, isolated test, review, regression, promote; no self-deploying unsupervised agent modifications.
- Multilingual voice field companion with offline optional speech recognition, explicit confirmation for data edits, plot/geotag context and secure sync.

## Standard interfaces

- BrAPI 2.1 stable for breeding program/study/observation data interoperability (https://brapi.org/specification).
- MIAPPE for minimum phenotyping experiment metadata (https://www.miappe.org/support/).
- OpenAI Agents SDK for optional approved tool-using coordinator and durable integrations, subject to data handling controls (https://openai.github.io/openai-agents-python/).

## Competitive differentiation / intellectual property

GURUDEV.ai cannot be called the first agentic breeding platform based solely on its concept: existing 2026 work includes BOLE (DOI 10.1016/j.jia.2026.07.011). Differentiation must be demonstrated with reproducible multi-crop scientific benchmarks, specific novel scientific algorithms, cross-module process integration, farmer/breeder voice workflows, and proven data governance—not marketing assertions. Consult appropriate technology transfer teams before IP claims.
