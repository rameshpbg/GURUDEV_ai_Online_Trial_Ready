# Scientific & Engineering Validation Gates

No analysis may be labelled **scientifically validated** solely because its code runs successfully.

## Gate 1 — Input integrity
- Species/crop/trait and units documented. Stable sample, environment, pedigree and marker IDs; no accidental merges.
- Ploidy, genotype encoding and reference assembly specified. HapMap/VCF/dosage conversions require independent checks.
- Detect unexpected missingness, duplicate identifiers, inconsistent replications, and non-numeric traits.

## Gate 2 — Experimental/statistical model
- Identify experimental unit, treatments, design, blocks, years, locations, randomization, confounding, estimand and assumptions.
- Select model design-aware; compare estimates to established reference implementations.
- Multi-environment analysis separates G, E, G×E, replication and appropriate covariance structures.

## Gate 3 — ML and genomic prediction
- All imputation/standardization/tuning inside training folds; grouped validation for families, environments and years as scientifically intended.
- Check external test cohorts, uncertainty, performance against baseline, calibration and possible leakage.
- Haplotype/marker-effect estimates need reference alleles and biological interpretation checks.

## Gate 4 — Agents and software
- Deterministic routing and permissions; no unintended write actions; idempotency or confirm/revert for actions.
- Audit hashes, software versions, random seeds, environment, warnings, error handling and test records.
- Automated tests include valid, missing, corrupted, shifted IDs, groups, duplicated plots, inconsistent units and unsafe requests.

## Gate 5 — Scientific reports
- Tables and figures provide sample sizes, units, axes, effect sizes, legends, threshold definitions and methods.
- Label synthetic/demonstration data prominently; do not fabricate statistical significance or cite nonexistent evidence.
- Explicit limitations, user-controlled decisions and independent review before claims/publication.

## v0.2 evidence
- 19 passing Python tests as of 2026-10-09; static JS syntax checked using Node.
- GP synthetic datasets: functional model execution and output verification.
- Browser voice: implemented browser APIs; actual device microphone/recognition/speech playback not validated in this environment.
- Legacy GURUDEV R/Shiny packages: not connected or tested.
