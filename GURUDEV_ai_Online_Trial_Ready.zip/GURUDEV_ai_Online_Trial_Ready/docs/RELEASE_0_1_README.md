# 🌾 GURUDEV.ai — v0.1 Research-Workflow Foundation

**GURUDEV.ai** is designed as the umbrella platform for GURUDEV Diversity, E-Design, GWAS, GP, Breeding Simulation, Digital Phenomics and future biotechnology modules.

**Status: tested foundation prototype, not a complete autonomous scientific agent or clinically/agronomically validated product.** Only genotype/phenotype CSV QC and an initial GP analysis engine are executable. Existing R/Shiny packages have *not* been imported.

## Quick start (Python 3.10+)

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux / macOS:
# source .venv/bin/activate
python -m pip install -e ".[dev]"
python -m gurudev_ai modules
python -m gurudev_ai plan "Perform genomic prediction of grain yield"
python -m gurudev_ai demo --output demo_run
python -m pytest -q
```

Optional visual dashboard:
```bash
python -m pip install -e ".[ui]"
streamlit run app.py
```

Your own genotype–phenotype dataset (CSV, sample rows, SNP columns):
```bash
python -m gurudev_ai run --module gp --genotype geno.csv --phenotype pheno.csv --trait GrainYield --output runs
# Group-aware nested CV (if family is included in phenotypes):
python -m gurudev_ai run --module gp --genotype geno.csv --phenotype pheno.csv --trait GrainYield --group family --output runs
```

QC only:
```bash
python -m gurudev_ai run --module qc --genotype geno.csv --phenotype pheno.csv --trait GrainYield
```

**Optional cloud AI advisory planner** (API charges may apply): install `pip install -e ".[llm]"`, set `OPENAI_API_KEY` in your environment (never put keys in source files), then run:
```bash
python -m gurudev_ai plan "Perform genomic prediction of grain yield" --llm
```
The AI route is restricted to implemented modules and cannot execute unrestricted code.

## Generated outputs
Each `runs/<job_id>/` directory includes `manifest.json` (input hashes and computational settings), `qc.json`, `events.jsonl`, `report.md`; GP adds `out_of_fold_predictions.csv` and `trained_model.joblib`. Metadata is indexed in `runs/gurudev_jobs.sqlite3`.

## Scientific interpretation
Ridge and ElasticNet are starter comparators; they are **not** equivalent to GBLUP, Bayesian genomic selection or multi-trait genomic prediction. Outer/inner nested CV guards against hyperparameter-selection leakage. CV strategy must match breeding goals; use family, location or year groups when generalization beyond observed material is the goal. An external test cohort is still needed for independent assessment.

## What's next
See `docs/PROGRAMME_MASTER.md` and `docs/ARCHITECTURE.md`. The prior GURUDEV R package ZIPs or GitHub repositories are required before they can be tested or integrated. The `.ai` name is a proposed product name: **domain and trademark availability have not been verified**.
